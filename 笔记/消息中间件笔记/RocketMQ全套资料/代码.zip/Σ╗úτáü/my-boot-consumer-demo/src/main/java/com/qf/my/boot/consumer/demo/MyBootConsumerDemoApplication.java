package com.qf.my.boot.consumer.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBootConsumerDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyBootConsumerDemoApplication.class, args);
    }

}
