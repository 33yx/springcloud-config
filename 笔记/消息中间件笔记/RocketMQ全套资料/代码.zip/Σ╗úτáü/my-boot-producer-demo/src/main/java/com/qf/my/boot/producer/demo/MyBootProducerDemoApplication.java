package com.qf.my.boot.producer.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBootProducerDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyBootProducerDemoApplication.class, args);
    }

}
